package utils

import (
	"os"
)

func GetCurrentUserDir() (path string, err error) {
	dirname, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return dirname, nil
}
