package utils

import (
	"io/ioutil"
	"os"
	"strconv"
)

// breakpointDir:断电续传临时文件目录
// fileDir:临时合成的文件目录
const (
	breakpointDir = "./breakpointDir/"
	finishDir     = "./fileDir/"
)

//@function: BreakPointContinue
//@description: 断点续传
//@param: content []byte, fileName string, contentNumber int, contentTotal int, fileMd5 string
//@return: error, string
func BreakPointContinue(content []byte, fileName string, contentNumber int, contentTotal int, fileMd5 string) (string, error) {
	path := breakpointDir + fileMd5 + "/"
	// Create folder path based on breakpointDir and md5
	err := os.MkdirAll(path, os.ModePerm)
	if err != nil {
		return path, err
	}
	//Path exists, create slice content
	pathC, err := makeFileContent(content, fileName, path, contentNumber)
	return pathC, err
}


//@function: CheckMd5
//@description: 检查Md5
//@param: content []byte, chunkMd5 string
//@return: CanUpload bool
func CheckMd5(content []byte,chunkMd5 string)(CanUpload bool){
	fileMd5 := MD5V(content)
	if fileMd5 == chunkMd5 {
		return true
	} else {
		return false
	}
}

//@function: makeFileContent
//@description: 创建切片内容
//@param: content []byte, fileName string, FileDir string, contentNumber int
//@return: string, error
func makeFileContent(content []byte,fileName string, FileDir string,contentNumber int)(string, error){
	//Add the number of slices to the end of the path
	path := FileDir + fileName + "_" + strconv.Itoa(contentNumber)
	//Create files to the specified directory
	f, err := os.Create(path)
	if err != nil {
		return path, err
	} else {
		//Write file contents
		_, err = f.Write(content)
		if err != nil {
			return path, err
		}
	}
	defer f.Close()
	return path, nil
}

//@function: MakeFile
//@description: 创建切片文件
//@param: fileName string, FileMd5 string
//@return: error, string

func MakeFile(fileName string, FileMd5 string)(string,error){
	// Read file contents
	readFile, err := ioutil.ReadDir(breakpointDir + FileMd5)
	if err != nil {
		return finishDir + fileName, err
	}
	_ = os.MkdirAll(finishDir,os.ModePerm)
	// os.OpenFile(path,oprn try,Control file mode)
	fd, err := os.OpenFile(finishDir + fileName, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0o644)
	if err != nil {
		return finishDir + fileName, err
	}
	defer fd.Close()
	for k := range readFile {
		content, _ := ioutil.ReadFile(breakpointDir + FileMd5 + "/" + fileName + "_" + strconv.Itoa(k))
		_, err = fd.Write(content)
		if err != nil {
			_ = os.Remove(finishDir + fileName)
			return finishDir + fileName, err
		}
	}
	return finishDir + fileName, nil
}

//@function: RemoveChunk
//@description: 移除切片
//@param: FileMd5 string
//@return: error
func RemoveChunk(FileMd5 string) error {
	// remove file
	err := os.RemoveAll(breakpointDir + FileMd5)
	return err
}
