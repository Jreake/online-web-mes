package main

import (
	"backend_go/src/global"
	"backend_go/src/initialize"
	"backend_go/src/server"
	"os"
	"path/filepath"
)

func main() {
	exePath := getExePath()
	server.InitViper(exePath)
	global.GVA_DB = initialize.Gorm()
	if global.GVA_DB != nil {
		initialize.RegisterTables(global.GVA_DB) // 初始化表
		db, _ := global.GVA_DB.DB()
		defer db.Close()
	}
	server.Init()
}

func getExePath() string {
	ex, err := os.Executable()
	if err != nil {
		panic(err)
	}
	exePath := filepath.Dir(ex)
	return exePath
}
