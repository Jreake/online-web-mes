package initialize

import (
	"backend_go/src/global"
	"backend_go/src/model"
	"backend_go/src/utils"
	"fmt"
	"os"

	"gorm.io/gorm"
)

// Gorm 初始化数据库并产生数据库全局变量
// Author SliverHorn
func Gorm() *gorm.DB {
	homeDir, err := utils.GetCurrentUserDir()
	if err != nil {
		return nil
	}
	fmt.Println(homeDir)
	switch global.GVA_CONFIG.System.DbType {
	case "sqlite":
		return GormSQlite(homeDir)
	default:
		return GormSQlite(homeDir)
	}
}

// RegisterTables 注册数据库表专用
// Author SliverHorn
func RegisterTables(db *gorm.DB) {
	err := db.AutoMigrate(
		// 系统模块表
		model.Test{},
	)
	if err != nil {
		os.Exit(0)
	}
}
