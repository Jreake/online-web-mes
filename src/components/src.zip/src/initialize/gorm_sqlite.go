package initialize

import (
	"backend_go/src/config"
	"backend_go/src/global"
	"backend_go/src/utils"
	"fmt"
	"path/filepath"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func GormSQlite(homeDir string) *gorm.DB {

	m := global.GVA_CONFIG.Sqlite
	fmt.Println(m)
	if m.Path == "" {
		return nil
	}

	dbPath := filepath.Join(homeDir, m.Path)
	db, _ := gorm.Open(sqlite.Open(dbPath), &gorm.Config{})
	return db
}

func GormSqliteByConfig(m config.Sqlite) *gorm.DB {
	homeDir, err := utils.GetCurrentUserDir()
	if err != nil {
		panic(err)
	}
	if m.Path == "" {
		panic("Missing sqlite db path")
	}

	dbPath := filepath.Join(homeDir, m.Path)

	if db, _ := gorm.Open(sqlite.Open(dbPath), &gorm.Config{}); err != nil {
		panic(err)
	} else {
		return db
	}
}
