package service

import (
	"backend_go/src/global"
	"backend_go/src/model"
	"errors"

	"gorm.io/gorm"
)

type FileUploadService struct{}


// @function: FindOrCreateFile
// @description: 上传文件时检测当前文件属性，如果没有文件则创建，有则返回当前文件的切片
// @params: fileMd5 string, fileName string, chunkTotal int
// @return: file model.ExaFile,err error
func (e *FileUploadService) FindOrCreateFile(fileMd5 string, fileName string, chunkTotal int) (file model.ExaFile, err error){
	var cfile model.ExaFile
	cfile.FileMd5 = fileMd5
	cfile.FileName = fileName
	cfile.ChunkTotal = chunkTotal

	if errors.Is(global.GVA_DB.Where("file_md5 = ? AND is_finish = ?", fileMd5,true).First(&file).Error, gorm.ErrRecordNotFound){
		err = global.GVA_DB.Where("file_md5 = ? AND file_name = ?",fileMd5,fileName).Preload("ExaFileChunk").FirstOrCreate(&file,cfile).Error
		return file, err
	}
	cfile.IsFinish = true
	cfile.FilePath = file.FilePath
	err = global.GVA_DB.Create(&cfile).Error
	return cfile, err
}

// @function: CreateFileChunk
// @description: 文件上传切片记录
// @params: id uint,fileChunkPath string,fileChunkNumber int
// @return: error
func (e *FileUploadService) CreateFileChunk(id uint, fileChunkPath string,fileChunkNumber int) error{
	var chunk model.ExaFileChunk
	chunk.FileChunkNumber = fileChunkNumber
	chunk.ExaFileID = id
	chunk.FileChunkPath = fileChunkPath
	err := global.GVA_DB.Create(&chunk).Error
	return err
}

// @function: DeleteFileChunk
// @description: 删除文件切片记录
// @params: fileMd5 string, fileName string, filePath string
// @return: error
func(e *FileUploadService) DeleteFileChunk(fileMd5 string, fileName string, filePath string) error{
	var chunks []model.ExaFileChunk
	var file model.ExaFile
	err := global.GVA_DB.Where("file_md5 = ? ",fileMd5).First(&file).Update("IsFinish",true).Update("file_path",filePath).Error
	if err != nil {
		return err
	}
	err = global.GVA_DB.Where("exa_file_id = ?", file.ID).Delete(&chunks).Unscoped().Error
	return err
}
