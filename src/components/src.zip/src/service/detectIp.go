package service

import (
	"errors"
	"net"
	"sync"
	"time"

	"fmt"

	"github.com/j-keck/arping"
)

type DetectIpService struct{}

// @function: GetActiveIpInLAN
// @description: 查询局域网内活跃的IP
// @param:
<<<<<<< HEAD
// @return: string[],error
func (e *DetectIpService) GetActiveIpInLAN() (ips []string, err error) {
	ipNet, err := getIPNet()

	if err != nil {
		return
	}
=======
// @return: string[]
func (e *DetectIpService) GetActiveIpInLAN() []string {
	ipNet := getIPNet()
>>>>>>> 11a2b046449d0ada15120c2abb3dfd4804f1f4b4
	ipList := getIPSet(ipNet)
	var activeIPList []string
	var wg sync.WaitGroup
	for _, ip := range ipList {
		wg.Add(1)
		go func(ip net.IP) {
			defer wg.Done()
			if isActiveIP(ip) {
				activeIPList = append(activeIPList, ip.String())
			}
		}(ip)
	}
	wg.Wait()
<<<<<<< HEAD
	ips = activeIPList
	return
}

// @function: GetActiveIpByArea
// @description: 查询ip范围内活跃的IP
// @param: startIp string
// @param: endIp string
// @param: max int 最大查询数量
// @return: string[],error
func (e *DetectIpService) GetActiveIpByArea(startIp, endIp net.IP, max int) (ips []string, err error) {
	ipList := getIPSetByArea(startIp, endIp, max)
	var activeIPList []string
	var wg sync.WaitGroup
	arping.SetTimeout(2 * time.Second)
	for _, ip := range ipList {
		wg.Add(1)
		go func(ip net.IP) {
			defer wg.Done()
			if isActiveIP(ip) {
				activeIPList = append(activeIPList, ip.String())
			}
		}(net.ParseIP(ip))
	}
	wg.Wait()
	ips = activeIPList
	return
}

// 获取当前IP的IPNet,可通过该信息获取内网IP的范围
func getIPNet() (ip *net.IPNet, err error) {
	addrs, err1 := net.InterfaceAddrs()
	if err1 != nil {
		err = errors.New("无法获取本地网络信息")
		return
	}
	arping.SetTimeout(2 * time.Second)
	for _, a := range addrs {
		if ipNet, ok := a.(*net.IPNet); ok && !ipNet.IP.IsLoopback() {
			if ipNet.IP.To4() != nil {
				ip = ipNet
				return
			}
		}
	}
	err = errors.New("无法获取本地网络信息")
	return
}

// 获取内网IP的枚举
=======
	fmt.Println(activeIPList)
	return activeIPList
}

// 获取当前IP的IPNet,可通过该信息获取内网IP的范围
func getIPNet() *net.IPNet {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		fmt.Println("无法获取本地网络信息:", err)
	}
	for i, a := range addrs {
		if ip, ok := a.(*net.IPNet); ok && !ip.IP.IsLoopback() {
			if ip.IP.To4() != nil {
				fmt.Println("IP:", ip.IP)
				fmt.Println("子网掩码:", ip.Mask)
				it, _ := net.InterfaceByIndex(i)
				fmt.Println("Mac地址:", it.HardwareAddr)
				return ip
			}
		}
	}
	return nil
}

// 获取内网IP的范围
>>>>>>> 11a2b046449d0ada15120c2abb3dfd4804f1f4b4
func getIPSet(ipNet *net.IPNet) (ipSet []net.IP) {
	var ipStringSet []string
	for ip := ipNet.IP.Mask(ipNet.Mask); ipNet.Contains(ip); nextIP(ip) {
		if ip[len(ip)-1]&0xff == 0 {
			continue
		}
		ipStringSet = append(ipStringSet, ip.String())
	}
	for _, ipString := range ipStringSet {
		ip := net.ParseIP(ipString)
		if ip != nil {
			ipSet = append(ipSet, ip)
		}
	}
	return
}

<<<<<<< HEAD
// 获取指定起始ip和最大长度的ip枚举
func getIPSetByArea(startIp, endIp net.IP, max int) (ipSet []string) {
	ip := startIp
	for {
		ipSet = append(ipSet, ip.String())
		nextIP(ip)
		if ip.Equal(endIp) {
			ipSet = append(ipSet, ip.String())
			break
		}
		if max == 0 {
			break
		}
		max--
	}
	return
}

=======
>>>>>>> 11a2b046449d0ada15120c2abb3dfd4804f1f4b4
// 根据当前IP获取下一个IP
func nextIP(ip net.IP) {
	for i := len(ip) - 1; i >= 0; i-- {
		ip[i]++
		if ip[i] > 0 {
			break
		}
	}
}

// 判断是否是活跃IP
func isActiveIP(ip net.IP) bool {
<<<<<<< HEAD
	if _, _, err := arping.Ping(ip); err != nil {
		return false
	} else {
=======
	// dstIP:=net.ParseIP(ip)
	if hwAddr, _, err := arping.Ping(ip); err != nil {
		fmt.Println(err)
		return false
	} else {
		fmt.Printf("%s is at %s\n", ip, hwAddr)
>>>>>>> 11a2b046449d0ada15120c2abb3dfd4804f1f4b4
		return true
	}
}
