package service

type ServiceGroup struct {
	DetectIpService
	FileUploadService
}

var ServiceGroupApp = new(ServiceGroup)
