package controller

import (
	"backend_go/src/common/response"
	"backend_go/src/service"
	"backend_go/src/utils"
	"fmt"
	"io/ioutil"
	"mime/multipart"
	"strconv"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

var (
	fileUploadService = service.ServiceGroupApp.FileUploadService
)

type FileUploadApi struct{}

// @Tags FileUploadApi
// @Summary 文件上传(支持断点续传到服务器)
// @Router /api/file/uploadFile [post]
// @Success 200 {object} response.Response{msg=string} "断点续传到服务器"
func(e *FileUploadApi) UploadFile(c *gin.Context){
	fileMd5 := c.Request.FormValue("fileMd5")
	fileName := c.Request.FormValue("fileName")
	chunkMd5 := c.Request.FormValue("chunkMd5")
	chunkNumber, _ := strconv.Atoi(c.Request.FormValue("chunkNumber"))
	chunkTotal, _ := strconv.Atoi(c.Request.FormValue("chunkTotal"))
	_, FileHeader, err := c.Request.FormFile("file")
	if err != nil {
		// global.GVA_LOG.Error("接收文件失败!",zap.Error(err))
		response.FailWithMessage("接收文件失败", c)
		return
	}
	f, err := FileHeader.Open()
	if err != nil {
		// global.GVA_LOG.Error("文件读取失败!", zap.Error(err))
		response.FailWithMessage("文件读取失败", c)
		return
	}
	defer func(f multipart.File) {
		err := f.Close()
		if err != nil {
			fmt.Println(err)
		}
	}(f)
	cen, _ := ioutil.ReadAll(f)
	if !utils.CheckMd5(cen, chunkMd5) {
		// global.GVA_LOG.Error("检查md5失败!", zap.Error(err))
		response.FailWithMessage("检查md5失败", c)
		return
	}
	file, err := fileUploadService.FindOrCreateFile(fileMd5, fileName, chunkTotal)
	if err != nil {
		// global.GVA_LOG.Error("查找或创建记录失败!", zap.Error(err))
		response.FailWithMessage("查找或创建记录失败", c)
		return
	}
	pathC, err := utils.BreakPointContinue(cen, fileName, chunkNumber, chunkTotal, fileMd5)
	if err != nil {
		// global.GVA_LOG.Error("断点续传失败!", zap.Error(err))
		response.FailWithMessage("断点续传失败", c)
		return
	}

	if err = fileUploadService.CreateFileChunk(file.ID, pathC, chunkNumber); err != nil {
		// global.GVA_LOG.Error("创建文件记录失败!", zap.Error(err))
		response.FailWithMessage("创建文件记录失败", c)
		return
	}
	response.OkWithMessage("切片创建成功", c)
}

// @Tags FileUploadApi
// @Summary 查找文件
// @Router /api/file/FindFile [post]
// @Success 200 {object} response.Response{data=FileResponse,msg=string} "查找文件,返回包
func (b *FileUploadApi) FindFile(c *gin.Context){
	response.OkWithMessage("成功", c)
}

// @Tags FileUploadApi
// @Summary 创建文件
// @Router /api/file/uploadFileFinish [post]
// @Success 200 {object} response.Response{data=exampleRes.FilePathResponse,msg=string} "创建文件,返回包括文件路径"
func (b *FileUploadApi) UploadFileFinish(c *gin.Context) {}


// @Tags FileUploadApi
// @Summary 删除切片
// @Router  /api/file/removeChunk [post]
// @Success 200 {object} response.Response{msg=string} "删除切片"
func (b *FileUploadApi) RemoveChunk(c *gin.Context) {}

var FileUploadApp = new(FileUploadApi)
