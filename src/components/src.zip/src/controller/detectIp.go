package controller

import (
	"backend_go/src/common/response"
	"backend_go/src/service"
	"net"

	"github.com/gin-gonic/gin"
)

type DetectIpApi struct {
}

var (
	DetectIpService = service.ServiceGroupApp.DetectIpService
)

// @Tags DetectIpApi
// @Summary 查询局域网内活跃的机器人ip
// @Router /api/detectIp [get]
// @Query {*}
// @Response {*}
func (e *DetectIpApi) DetectIp(c *gin.Context) {
<<<<<<< HEAD
	ipList, err := DetectIpService.GetActiveIpInLAN()
	if err == nil {
		response.OkWithDetailed(ipList, "获取成功", c)
	} else {
		response.FailWithMessage("获取失败", c)
	}

=======
	ipList := DetectIpService.GetActiveIpInLAN()
	response.OkWithDetailed(ipList, "获取成功", c)
>>>>>>> 11a2b046449d0ada15120c2abb3dfd4804f1f4b4
}

// @Tags DetectIpApi
// @Summary 根据ip范围查询局域网内活跃的机器人ip
// @Router /api/detectIpByArea [get]
// @Query {*} startIp 范围起始IP
// @Query {*} endIp   范围终止Ip
// @Response {*}
func (e *DetectIpApi) DetectIpByArea(c *gin.Context) {
<<<<<<< HEAD
	max := 50
	startIp := c.Query("startIp")
	endIp := c.Query("endIp")
	startIpNat := net.ParseIP(startIp)
	endIpNet := net.ParseIP(endIp)
	if startIpNat == nil || endIpNet == nil {
		response.FailWithMessage("获取失败", c)
	}
	ipList, err := DetectIpService.GetActiveIpByArea(startIpNat, endIpNet, max)
	if err == nil {
		response.OkWithDetailed(ipList, "获取成功", c)
	} else {
		response.FailWithMessage("获取失败", c)
=======
	startIp := c.Query("startIp")
	endIp := c.Query("endIp")
	isStartIpCorrect := net.ParseIP(startIp)
	isEndIpCorrect := net.ParseIP(endIp)
	if isStartIpCorrect == nil || isEndIpCorrect == nil {
		response.OkWithMessage("成功", c)
	} else {
		response.OkWithMessage("成功", c)
>>>>>>> 11a2b046449d0ada15120c2abb3dfd4804f1f4b4
	}

}

var DetectIpApp = new(DetectIpApi)
