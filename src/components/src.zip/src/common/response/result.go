package response

import (
	"backend_go/src/common/constant"
	"net/http"

	"github.com/gin-gonic/gin"
)

type Response struct {
	Code      constant.ResponseCode `json:"code"`
	Message   constant.ResponseMsg  `json:"message"`
	Origin    string                `json:"origin"`
	Data      interface{}           `json:"data"` // 返回数据
	RequestId string                `json:"requestId"`
}

const (
	ERROR   = 7
	SUCCESS = 0
)

func Result(code constant.ResponseCode, data interface{}, msg constant.ResponseMsg, c *gin.Context) {
	// 开始时间
	c.JSON(http.StatusOK, Response{
		Code:      code,
		Message:   msg,
		Origin:    "",
		Data:      data,
		RequestId: "",
	})
}

func Ok(c *gin.Context) {
	Result(constant.SuccessCode, map[string]interface{}{}, constant.SuccessMsg, c)
}

func OkWithMessage(message constant.ResponseMsg, c *gin.Context) {
	Result(constant.SuccessCode, map[string]interface{}{}, message, c)
}

func OkWithData(data interface{}, c *gin.Context) {
	Result(constant.SuccessCode, data, constant.SuccessMsg, c)
}

func OkWithDetailed(data interface{}, message constant.ResponseMsg, c *gin.Context) {
	Result(constant.SuccessCode, data, message, c)
}

func Fail(c *gin.Context) {
	Result(constant.FailedCode, map[string]interface{}{}, constant.FailedMsg, c)
}

func FailWithMessage(message string, c *gin.Context) {
	Result(constant.FailedCode, map[string]interface{}{}, constant.FailedMsg, c)
}

func FailWithDetailed(data interface{}, message string, c *gin.Context) {
	Result(constant.FailedCode, data, constant.FailedMsg, c)
}
