package constant

type ResponseCode string
type ResponseMsg string

const (
	SuccessCode ResponseCode = "00000"
	SuccessMsg  ResponseMsg  = "success"

	FailedCode ResponseCode = "99999"
	FailedMsg  ResponseMsg  = "failed"
)
