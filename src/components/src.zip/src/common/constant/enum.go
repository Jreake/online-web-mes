package constant

// 批量升级任务状态
type RobotBatchOtaStatus string

const (
	ROBOT_BATCH_OTA_STATE_INIT      RobotBatchOtaStatus = "INIT"      //暂无批量升级任务，空闲
	ROBOT_BATCH_OTA_STATE_UPGRADING RobotBatchOtaStatus = "UPGRADING" // 正在执行批量升级中
	ROBOT_BATCH_OTA_STATE_SUCCESS   RobotBatchOtaStatus = "SUCCESS"   // 批量升级结束
)

// 机器人升级状态
type RobotOtaState string

const (
	ROBOT_OTA_STATE_WAIT_UPLOAD  RobotOtaState = "WAIT_UPLOAD"
	ROBOT_OTA_STATE_UPLOADING    RobotOtaState = "UPLOADING"
	ROBOT_OTA_STATE_WAIT_UPGRADE RobotOtaState = "WAIT_UPGRADE"
	ROBOT_OTA_STATE_UPGRADING    RobotOtaState = "UPGRADING"
	ROBOT_OTA_STATE_WAIT_REBOOT  RobotOtaState = "WAIT_REBOOT"
	ROBOT_OTA_STATE_SUCCESS      RobotOtaState = "SUCCESS"
	ROBOT_OTA_STATE_ABORT        RobotOtaState = "ABORT"
	ROBOT_OTA_STATE_STOP         RobotOtaState = "STOP"
)

// 机器人升级策略
type RobotOtaUpgradeTimeType int

const (
	ROBOT_OTA_UPGRADE_TIME_TYPE_IDLE    = 1 // 闲时升级
	ROBOT_OTA_UPGRADE_TIME_TYPE_NO_WAIT = 2 // 立即升级
)

// 机器人OTA重启侧类
type RobotOtaRebootType int

const (
	ROBOT_OTA_REBOOT_T_NO_WAIT RobotOtaRebootType = 1 //升级完后立即重启
	ROBOT_OTA_REBOOT_T_MANUAL  RobotOtaRebootType = 2 // 升级完后手动重启
)
