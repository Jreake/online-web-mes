package server

import (
	"backend_go/src/global"
	"backend_go/src/router"

	"log"

	"github.com/gin-gonic/gin"
)

func Init() {
	config := GetConfig()

	err := global.SetupGlobalCache()
	if err != nil {
		log.Fatalf("init.setupSetting err: %v", err)
	}

	err := global.SetupGlobalCache()
	if err != nil {
		log.Fatalf("init.setupSetting err: %v", err)
	}

	var (
		host string
		port string
	)
	host_key := "launch.http.host"
	if config.IsSet(host_key) {
		host = config.GetString("launch.http.host")
	} else {
		host = "0.0.0.0"
	}
	port_key := "launch.http.port"
	if config.IsSet(port_key) {
		port = config.GetString("launch.http.port")
	} else {
		port = "6000"
	}

	r := initRoutes()
	r.Run(host + ":" + port)
}

func initRoutes() *gin.Engine {
	Router := gin.Default()
	PrivateGroup := Router.Group("api")
	{
		router.RouterGroupApp.DetectIpRouter.InitRouter(PrivateGroup) // 探测IP路由
		router.RouterGroupApp.FileUploadRouter.InitRouter(PrivateGroup) //文件上传
	}
	return Router
}
