package server

import (
	"backend_go/src/global"
	"fmt"
	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
	"log"
	"path/filepath"
)

var v *viper.Viper

func InitViper(workingdir string) {
	var err error
	v = viper.New()
	v.SetConfigFile("config.yaml")
	v.SetConfigType("yaml")
	v.SetConfigName("config")
	v.AddConfigPath("./config")
	v.AddConfigPath(filepath.Join(workingdir, "config"))
	err = v.ReadInConfig()
	if err != nil {
		log.Fatal(err)
		log.Fatal("error on parsing configuration file")
	}
	v.WatchConfig()
	v.OnConfigChange(func(e fsnotify.Event) {
		fmt.Println("config file changed:", e.Name)
		if err = v.Unmarshal(&global.GVA_CONFIG); err != nil {
			fmt.Println(err)
		}
	})
	if err = v.Unmarshal(&global.GVA_CONFIG); err != nil {
		fmt.Println(err)
	}
	fmt.Println(global.GVA_CONFIG)
}

func GetConfig() *viper.Viper {
	return v
}
