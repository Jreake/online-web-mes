package cache

import (
	"backend_go/src/common/constant"
	"backend_go/src/global"
	"encoding/json"
)

type BatchOtaProcecesCache struct {
	Status        constant.RobotBatchOtaStatus
	UpgradeType   int
	TargetVersion string
	SourceVersion string
}

type OtaStateCache struct {
	Host             string
	UpgradeType      int
	RobotOtaState    constant.RobotOtaState
	UploadProgress   float32
	UploadRemainTime int
	UpgradeProgress  float32
	StartTime        int
	EndTime          int
	FailReason       string
	UpgradeTimeType  int
	UpgradeTime      int
	RebootType       constant.RobotOtaRebootType
}

func GetBatchOtaProcessCacheKey(requestId string) (cacheKey string) {
	return "batch_ota_process__" + requestId
}

func GetBatchOtaProcessCache(requestId string) (*BatchOtaProcecesCache, error) {
	cacheKey := GetBatchOtaProcessCacheKey(requestId)
	val, err := global.BigCache.Get(cacheKey)
	if err != nil {
		return nil, err
	} else {
		cacheObject := BatchOtaProcecesCache{}
		if err := json.Unmarshal([]byte(val), &cacheObject); err != nil {
			return nil, err
		}
		return &cacheObject, nil
	}
}

func SetBatchOtaProcessCache(requestId string, batchOtaProcess *BatchOtaProcecesCache) error {
	cacheKey := GetBatchOtaProcessCacheKey(requestId)
	content, err := json.Marshal(batchOtaProcess)
	if err != nil {
		return err
	}
	errSet := global.BigCache.Set(cacheKey, []byte(content))
	if errSet != nil {
		return errSet
	}
	return nil

}

func GetOtaStateCacheKey(requestId string, hostIp string) string {
	return "batch_ota_robot_state__" + requestId + "__" + hostIp
}

func GetOtaStateCache(requestId string, hostIp string) (*OtaStateCache, error) {
	cacheKey := GetOtaStateCacheKey(requestId, hostIp)
	val, err := global.BigCache.Get(cacheKey)
	if err != nil {
		return nil, err
	} else {
		cacheObject := OtaStateCache{}
		if err := json.Unmarshal([]byte(val), &cacheObject); err != nil {
			return nil, err
		}
		return &cacheObject, nil
	}
}

func InitOtaStateCache(requestId string, hostIp string) error {
	cacheKey := GetOtaStateCacheKey(requestId, hostIp)
	content, err := json.Marshal(&OtaStateCache{
		Host:             hostIp,
		RobotOtaState:    constant.ROBOT_OTA_STATE_WAIT_UPLOAD,
		UploadProgress:   0,
		UploadRemainTime: 0,
		UpgradeProgress:  0,
		StartTime:        0,
		EndTime:          0,
		FailReason:       "",
		UpgradeTimeType:  1,
		RebootType:       1,
	})
	if err != nil {
		return err
	}
	errSet := global.BigCache.Set(cacheKey, []byte(content))
	if errSet != nil {
		return err
	}
	return nil
}

func SetOtaUploadStateCache(requestId string, hostIp string, otaState *OtaStateCache) error {
	cacheKey := GetOtaStateCacheKey(requestId, hostIp)
	content, err := json.Marshal(otaState)
	if err != nil {
		return err
	}
	errSet := global.BigCache.Set(cacheKey, []byte(content))
	if errSet != nil {
		return errSet
	}
	return nil
}
