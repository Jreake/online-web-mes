package router

type RouterGroup struct {
	DetectIpRouter
	FileUploadRouter
}

var RouterGroupApp = new(RouterGroup)
