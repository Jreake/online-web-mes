package router

import (
	"backend_go/src/controller"

	"github.com/gin-gonic/gin"
)

type FileUploadRouter struct{}

func (e *FileUploadRouter) InitRouter(Router *gin.RouterGroup){
	fileUploadRouter := Router.Group("file")
	fileUploadApi := controller.FileUploadApp
	{
		fileUploadRouter.POST("uploadFile", fileUploadApi.UploadFile)
		fileUploadRouter.POST("findFile",fileUploadApi.FindFile)
	}
}
