package router

import (
	"backend_go/src/controller"

	"github.com/gin-gonic/gin"
)

type DetectIpRouter struct{}

func (e *DetectIpRouter) InitRouter(Router *gin.RouterGroup) {
	detectIpRouter := Router.Group("detectIp")
	detectIpApi := controller.DetectIpApp
	{
		detectIpRouter.GET("", detectIpApi.DetectIp)
		detectIpRouter.GET("area", detectIpApi.DetectIpByArea)
	}
}

// func (e *DetectIpRouter) DetectIp(r *gin.Engine) {
// 	detectIpApi := controller.
// 		Router.Group("/api", func(api group) {
// 		api.Registered(GET, "/detectIpByArea", controller.DetectIpByArea(context))

// 	})

// }
