package model

import (
	"backend_go/src/global"
)

type Test struct {
	global.GVA_MODEL
	Msg string `json:"msg" gorm:"comment:消息"`
}

func (Test) TableName() string {
	return "test_model"
}
